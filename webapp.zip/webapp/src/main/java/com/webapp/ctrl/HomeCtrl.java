package com.webapp.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeCtrl 
{
	@RequestMapping(value="/",method = RequestMethod.GET)
	public String home(Model m)
	{
		m.addAttribute("value", "Software Development");
		
		return "index";
	}
	@RequestMapping(value="/about",method = RequestMethod.GET)
	public String about(Model m)
	{
		m.addAttribute("value", "about");
		
		return "about";
	}
	@RequestMapping(value="/agent-single",method = RequestMethod.GET)
	public String agent(Model m)
	{
		m.addAttribute("value", "agent-single");
		
		return "agent-single";
	}
	@RequestMapping(value="/agents-grid",method = RequestMethod.GET)
	public String agents(Model m)
	{
		m.addAttribute("value", "agents-grid");
		
		return "agents-grid";
	}
	@RequestMapping(value="/contact",method = RequestMethod.GET)
	public String contact(Model m)
	{
		m.addAttribute("value", "contact");
		
		return "contact";
	}
	@RequestMapping(value="/portfolio-grid",method = RequestMethod.GET)
	public String portfolios(Model m)
	{
		m.addAttribute("value", "Software Development");
		
		return "portfolio-grid";
	}
	@RequestMapping(value="/portfolio-single",method = RequestMethod.GET)
	public String portfolio(Model m)
	{
		m.addAttribute("value", "Software Development");
		
		return "portfolio";
	}
	
}
